#!/bin/sh

cd /opt/forticlient-sslvpn
./fortisslvpn.sh

